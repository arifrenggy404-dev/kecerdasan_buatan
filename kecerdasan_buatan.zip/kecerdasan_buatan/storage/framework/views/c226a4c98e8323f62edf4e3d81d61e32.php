<?php $__env->startSection('title', 'Data Mata Kuliah'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">Kurikulum & Mata Kuliah</h3>
        <p class="text-muted small mb-0">Kelola mata kuliah dan plotting dosen pengampu</p>
    </div>
    <a href="<?php echo e(route('schedules.index')); ?>" class="btn btn-outline-secondary rounded-pill px-4 shadow-sm transition-all hover-translate-y">
        <i class="bi bi-house-door me-1"></i> Kembali ke Beranda
    </a>
</div>

<div class="row g-4">
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-header bg-white border-bottom py-3">
                <h5 class="fw-bold mb-0">Plotting Mata Kuliah</h5>
            </div>
            <div class="card-body p-4">
                <form action="<?php echo e(route('courses.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label fw-medium small text-uppercase text-muted">Template Mata Kuliah</label>
                        <select name="course_id" class="form-select bg-light" id="courseSelect">
                            <option value="">-- Buat Mata Kuliah Baru --</option>
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($c->id); ?>" data-name="<?php echo e($c->name); ?>" data-code="<?php echo e($c->code); ?>" data-sks="<?php echo e($c->sks); ?>" data-type="<?php echo e($c->type); ?>">
                                    [<?php echo e($c->code); ?>] <?php echo e($c->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="form-text small">Pilih jika ingin menambah pengampu pada MK yang sudah ada.</div>
                    </div>

                    <div id="newCourseFields" class="bg-light p-3 rounded-3 mb-4">
                        <div class="mb-3">
                            <label class="form-label fw-medium">Nama Mata Kuliah</label>
                            <input type="text" name="name" class="form-control" id="course_name" placeholder="Contoh: Algoritma">
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-medium">Kode MK</label>
                            <input type="text" name="code" class="form-control" id="course_code" placeholder="Contoh: AL01">
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-0">
                                <label class="form-label fw-medium">SKS</label>
                                <input type="number" name="sks" class="form-control" id="course_sks" min="1" max="6" value="2" required>
                            </div>
                            <div class="col-md-6 mb-0">
                                <label class="form-label fw-medium">Jenis</label>
                                <select name="type" class="form-select" id="course_type" required>
                                    <option value="theory">Teori</option>
                                    <option value="lab">Praktikum</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-medium small text-uppercase text-muted">Penugasan Dosen</label>
                        <select name="lecturer_id" class="form-select bg-primary-subtle border-primary-subtle" required>
                            <option value="">-- Pilih Dosen Pengampu --</option>
                            <?php $__currentLoopData = $lecturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($l->id); ?>"><?php echo e($l->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100 rounded-pill py-2 fw-bold shadow-sm mt-2">Simpan Plotting</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
            <div class="card-header bg-white border-bottom py-3">
                <h5 class="fw-bold mb-0">Daftar Mata Kuliah & Pengampu</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light text-muted small text-uppercase">
                            <tr>
                                <th class="ps-4 border-0 py-3" style="width: 100px;">Kode</th>
                                <th class="border-0 py-3">Mata Kuliah</th>
                                <th class="border-0 py-3">Pengampu & SKS</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="ps-4 py-3">
                                    <span class="badge bg-light text-dark border px-2 py-1"><?php echo e($c->code); ?></span>
                                </td>
                                <td class="py-3">
                                    <div class="d-flex justify-content-between align-items-center me-3">
                                        <div class="fw-bold text-dark"><?php echo e($c->name); ?></div>
                                        <button class="btn btn-sm btn-link text-decoration-none p-0" data-bs-toggle="modal" data-bs-target="#editCourseModal<?php echo e($c->id); ?>">
                                            <small><i class="bi bi-pencil-square me-1"></i> Edit MK</small>
                                        </button>
                                    </div>

                                    <!-- Edit Course Modal -->
                                    <div class="modal fade" id="editCourseModal<?php echo e($c->id); ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content border-0 shadow-lg rounded-4">
                                                <form action="<?php echo e(route('courses.update', $c->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                                    <div class="modal-header border-bottom-0 pt-4 px-4">
                                                        <h5 class="fw-bold mb-0">Edit Mata Kuliah</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body p-4 text-start">
                                                        <div class="mb-3">
                                                            <label class="form-label fw-medium">Nama Mata Kuliah</label>
                                                            <input type="text" name="name" class="form-control bg-light" value="<?php echo e($c->name); ?>" required>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label fw-medium">Kode MK</label>
                                                            <input type="text" name="code" class="form-control bg-light" value="<?php echo e($c->code); ?>">
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-6 mb-3">
                                                                <label class="form-label fw-medium">SKS Default</label>
                                                                <input type="number" name="sks" class="form-control bg-light" value="<?php echo e($c->sks); ?>" min="1" max="6" required>
                                                            </div>
                                                            <div class="col-md-6 mb-3">
                                                                <label class="form-label fw-medium">Jenis Default</label>
                                                                <select name="type" class="form-select bg-light" required>
                                                                    <option value="theory" <?php echo e($c->type == 'theory' ? 'selected' : ''); ?>>Teori</option>
                                                                    <option value="lab" <?php echo e($c->type == 'lab' ? 'selected' : ''); ?>>Praktikum</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer border-top-0 pb-4 px-4 d-flex justify-content-between">
                                                        <button type="button" class="btn btn-outline-danger rounded-pill px-4" onclick="if(confirm('Hapus MK ini beserta seluruh plottingnya?')) document.getElementById('deleteCourse<?php echo e($c->id); ?>').submit()">Hapus MK</button>
                                                        <div>
                                                            <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Batal</button>
                                                            <button type="submit" class="btn btn-primary rounded-pill px-4 fw-bold">Simpan</button>
                                                        </div>
                                                    </div>
                                                </form>
                                                <form id="deleteCourse<?php echo e($c->id); ?>" action="<?php echo e(route('courses.destroy', $c->id)); ?>" method="POST" style="display:none;">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="p-0">
                                    <div class="list-group list-group-flush">
                                        <?php $__currentLoopData = $c->offerings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="list-group-item bg-transparent d-flex justify-content-between align-items-center border-0 py-2 ps-0 pe-4">
                                                <div>
                                                    <div class="small fw-bold"><?php echo e($o->lecturer->name); ?></div>
                                                    <div class="d-flex gap-1 mt-1">
                                                        <span class="badge bg-primary-subtle text-primary border border-primary-subtle rounded-pill" style="font-size: 0.65rem;"><?php echo e($o->sks); ?> SKS</span>
                                                        <span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle rounded-pill" style="font-size: 0.65rem;"><?php echo e(ucfirst($o->type)); ?></span>
                                                    </div>
                                                </div>
                                                <div class="d-flex gap-2">
                                                    <button class="btn btn-sm btn-light border rounded-circle p-0" style="width: 28px; height: 28px;" data-bs-toggle="modal" data-bs-target="#editOfferingModal<?php echo e($o->id); ?>" title="Edit Plotting"><i class="bi bi-pencil-fill" style="font-size: 0.75rem;"></i></button>
                                                    <form action="<?php echo e(route('course-offerings.destroy', $o->id)); ?>" method="POST" onsubmit="return confirm('Hapus plotting ini?')">
                                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-sm btn-light border text-danger rounded-circle p-0" style="width: 28px; height: 28px;" title="Hapus Plotting"><i class="bi bi-trash-fill" style="font-size: 0.75rem;"></i></button>
                                                    </form>
                                                </div>

                                                <!-- Edit Offering Modal -->
                                                <div class="modal fade" id="editOfferingModal<?php echo e($o->id); ?>" tabindex="-1" aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered">
                                                        <div class="modal-content border-0 shadow-lg rounded-4">
                                                            <form action="<?php echo e(route('course-offerings.update', $o->id)); ?>" method="POST">
                                                                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                                                <div class="modal-header border-bottom-0 pt-4 px-4">
                                                                    <h5 class="fw-bold mb-0">Edit Plotting Mata Kuliah</h5>
                                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body p-4 text-start">
                                                                    <div class="p-3 bg-light rounded-3 mb-3">
                                                                        <small class="text-muted text-uppercase fw-bold">Mata Kuliah</small>
                                                                        <div class="fw-bold text-primary"><?php echo e($c->name); ?></div>
                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <label class="form-label fw-medium">Dosen Pengampu</label>
                                                                        <select name="lecturer_id" class="form-select" required>
                                                                            <?php $__currentLoopData = $lecturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <option value="<?php echo e($l->id); ?>" <?php echo e($o->lecturer_id == $l->id ? 'selected' : ''); ?>><?php echo e($l->name); ?></option>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </select>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-md-6 mb-0">
                                                                            <label class="form-label fw-medium">SKS</label>
                                                                            <input type="number" name="sks" class="form-control" value="<?php echo e($o->sks); ?>" min="1" max="6" required>
                                                                        </div>
                                                                        <div class="col-md-6 mb-0">
                                                                            <label class="form-label fw-medium">Jenis</label>
                                                                            <select name="type" class="form-select" required>
                                                                                <option value="theory" <?php echo e($o->type == 'theory' ? 'selected' : ''); ?>>Teori</option>
                                                                                <option value="lab" <?php echo e($o->type == 'lab' ? 'selected' : ''); ?>>Praktikum</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer border-top-0 pb-4 px-4">
                                                                    <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Batal</button>
                                                                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-bold">Simpan Perubahan</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="3" class="text-center py-5">
                                    <div class="text-muted opacity-50">
                                        <div class="display-1 mb-2"><i class="bi bi-journal-x"></i></div>
                                        <p class="mb-0">Belum ada data mata kuliah.</p>
                                    </div>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .transition-all { transition: all 0.2s ease; }
    .hover-translate-y:hover { transform: translateY(-2px); }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    const courseSelect = document.getElementById('courseSelect');
    const fields = ['name', 'code'];
    const fieldContainer = document.getElementById('newCourseFields');

    courseSelect.addEventListener('change', function() {
        if (this.value) {
            const selected = this.options[this.selectedIndex];
            fieldContainer.classList.add('bg-primary-subtle');
            fields.forEach(f => {
                const el = document.getElementById('course_' + f);
                el.value = selected.getAttribute('data-' + f);
                el.readOnly = true;
            });
            document.getElementById('course_sks').value = selected.getAttribute('data-sks');
            document.getElementById('course_type').value = selected.getAttribute('data-type');
        } else {
            fieldContainer.classList.remove('bg-primary-subtle');
            fields.forEach(f => {
                const el = document.getElementById('course_' + f);
                el.value = '';
                el.readOnly = false;
            });
            document.getElementById('course_sks').value = 2;
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /storage/emulated/0/htdocs/kecerdasan_buatan/resources/views/courses/index.blade.php ENDPATH**/ ?>